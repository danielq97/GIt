package co.edu.icesi.mio.exceptions;

public class LogicException extends Exception {

	public LogicException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}
}
