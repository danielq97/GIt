package co.edu.icesi.mio.test;

import static org.junit.Assert.*;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;

import org.junit.Test;

import co.edu.icesi.mio.dao.Tmio1RutaDAO;
import co.edu.icesi.mio.model.Tmio1Ruta;
import co.edu.icesi.mio.model.Tmio1Servicio;
import co.edu.icesi.mio.model.Tmio1ServiciosSitio;
import co.edu.icesi.mio.model.Tmio1SitiosRuta;

public class TestRutas {

	Tmio1RutaDAO tmioRutaDAO = new Tmio1RutaDAO();
	EntityManager entityManager = Persistence.createEntityManagerFactory("Miniproyect").createEntityManager();
	
	
	@Test
	 public void aTest() {

		
	 assertNotNull(tmioRutaDAO);
	
	
	 tmioRutaDAO.iniciarT(entityManager);
	 Tmio1Ruta truta = new Tmio1Ruta();
	truta.setActiva("S");
	truta.setDescripcion("Por la pasoancho");
	truta.setDiaFin(new BigDecimal(20));
	truta.setDiaInicio(new BigDecimal(30));
	truta.setHoraFin(new BigDecimal(12));
	truta.setHoraInicio(new BigDecimal(10));
	truta.setNumero("201");
	truta.setTmio1Servicios(new ArrayList<Tmio1Servicio>());
	truta.setTmio1ServiciosSitios(new ArrayList<Tmio1ServiciosSitio>());
	truta.setTmio1SitiosRutas2(new ArrayList<Tmio1SitiosRuta> ());
	
	 try {
	 tmioRutaDAO.save(entityManager, truta);
	 } catch (Exception e) {
	 // TODO: handle exception
	 tmioRutaDAO.rollback(entityManager);
	 }
	
	 tmioRutaDAO.cerrarT(entityManager);
	 }

	@Test
	public void bTest() {

		assertNotNull(tmioRutaDAO);
		tmioRutaDAO.iniciarT(entityManager);
		Tmio1Ruta ruta = tmioRutaDAO.findById(entityManager, 4);
		assertNotNull("Code not found", ruta);
		ruta.setDescripcion("POr la cañasgordas");
		try {
			tmioRutaDAO.update(entityManager, ruta);
		} catch (Exception e) {
			// TODO: handle exception
			tmioRutaDAO.rollback(entityManager);
		}
	

		tmioRutaDAO.cerrarT(entityManager);
	}

	 @Test
	 public void cTest() {
	
	 assertNotNull(tmioRutaDAO);
	 tmioRutaDAO.iniciarT(entityManager);
	 Tmio1Ruta Tmio1RutaDAO =
	 tmioRutaDAO.findById(entityManager, 4);
	 assertNotNull("Code not found", Tmio1RutaDAO);
	 try {
	 tmioRutaDAO.delete(entityManager, Tmio1RutaDAO);
	 } catch (Exception e) {
	 // TODO: handle exception
	 tmioRutaDAO.rollback(entityManager);
	 }

	
	 tmioRutaDAO.cerrarT(entityManager);
	
	
	 }

}
