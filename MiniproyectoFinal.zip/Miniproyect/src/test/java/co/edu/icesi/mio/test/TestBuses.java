package co.edu.icesi.mio.test;

import static org.junit.Assert.*;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.junit.Test;

import co.edu.icesi.mio.dao.Tmio1BusDAO;
import co.edu.icesi.mio.dao.Tmio1BusDAO;
import co.edu.icesi.mio.model.Tmio1Bus;
import co.edu.icesi.mio.model.Tmio1Servicio;
import co.edu.icesi.mio.model.Tmio1ServiciosSitio;
import co.edu.icesi.mio.model.Tmio1Bus;

public class TestBuses {

	Tmio1BusDAO tmiobusDAO = new Tmio1BusDAO();

	EntityManager entityManager = Persistence.createEntityManagerFactory("Miniproyect").createEntityManager();

	 @Test
	 public void aTest() {
	
	
	
	 assertNotNull(tmiobusDAO);
	
	
	 tmiobusDAO.iniciarT(entityManager);
	 Tmio1Bus tbus = new Tmio1Bus();
	tbus.setCapacidad(new BigDecimal(60));
	tbus.setId(2);
	tbus.setMarca("Chevrolet");
	tbus.setModelo(new BigDecimal(1997));
	tbus.setPlaca("ABC 233");
	tbus.setTipo("Camioneta");
	tbus.setTmio1Servicios(new ArrayList<Tmio1Servicio>());
	tbus.setTmio1ServiciosSitios(new ArrayList<Tmio1ServiciosSitio>());
	
	 try {
	 tmiobusDAO.save(entityManager, tbus);
	 } catch (Exception e) {
	 // TODO: handle exception
	 tmiobusDAO.rollback(entityManager);
	 }
	
	 tmiobusDAO.cerrarT(entityManager);
	 }

	@Test
	public void bTest() {

		assertNotNull(tmiobusDAO);
		tmiobusDAO.iniciarT(entityManager);
		Tmio1Bus bus = tmiobusDAO.findByModelo(entityManager, new BigDecimal(1997));
		assertNotNull("Code not found", bus);
		bus.setModelo(new BigDecimal(1997));
		try {
			tmiobusDAO.update(entityManager, bus);
		} catch (Exception e) {
			// TODO: handle exception
			tmiobusDAO.rollback(entityManager);
		}
//		Query query =    entityManager
//				.createQuery("FROM Tmio1Bus t ORDER BY TO_DATE(t.fechaNacimiento, \"DD/MM/YY\") DESC");
//		List<String> list = query.getResultList();
//
//		System.out.println("Obtencion:  " + list.get(0));

		tmiobusDAO.cerrarT(entityManager);
	}

	 @Test
	 public void cTest() {
	
	 assertNotNull(tmiobusDAO);
	 tmiobusDAO.iniciarT(entityManager);
	 Tmio1Bus Tmio1Bus =tmiobusDAO.findByCapacidad(entityManager, new BigDecimal(60));
	 assertNotNull("Code not found", Tmio1Bus);
	 try {
	 tmiobusDAO.delete(entityManager, Tmio1Bus);
	 } catch (Exception e) {
	 // TODO: handle exception
	 tmiobusDAO.rollback(entityManager);
	 }
	
	
	 tmiobusDAO.cerrarT(entityManager);
	
	
	 }

}
