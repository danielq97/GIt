package co.edu.icesi.mio.test;

import static org.junit.Assert.*;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import co.edu.icesi.mio.dao.ITMio1ConductoreDAO;
import co.edu.icesi.mio.dao.Tmio1ConductoreDAO;
import co.edu.icesi.mio.model.Tmio1Conductore;
import co.edu.icesi.mio.model.Tmio1Servicio;
import co.edu.icesi.mio.model.Tmio1ServiciosSitio;

public class TestConductores {

	Tmio1ConductoreDAO tmioConductoresDAO = new Tmio1ConductoreDAO();

	EntityManager entityManager = Persistence.createEntityManagerFactory("Miniproyect").createEntityManager();

	 @Test
	 public void aTest() {
	
	
	
	 assertNotNull(tmioConductoresDAO);
	
	
	 tmioConductoresDAO.iniciarT(entityManager);
	 Tmio1Conductore tconductor = new Tmio1Conductore();
	 tconductor.setCedula("12326");
	 tconductor.setApellidos("Quintero");
	 tconductor.setFechaContratacion(new Date(0));
	 tconductor.setFechaNacimiento(new java.util.Date(45, 11, 22));
	 tconductor.setNombre("MArco");
	 tconductor.setTmio1Servicios(new ArrayList <Tmio1Servicio> ());
	 tconductor.setTmio1ServiciosSitios(new ArrayList <Tmio1ServiciosSitio> ());
	
	
	 try {
	 tmioConductoresDAO.save(entityManager, tconductor);
	 } catch (Exception e) {
	 // TODO: handle exception
	 tmioConductoresDAO.rollback(entityManager);
	 }
	
	 tmioConductoresDAO.cerrarT(entityManager);
	 }

	@Test
	public void bTest() {

		assertNotNull(tmioConductoresDAO);
		tmioConductoresDAO.iniciarT(entityManager);
		Tmio1Conductore conductor = tmioConductoresDAO.findByCedula(entityManager, "12326");
		assertNotNull("Code not found", conductor);
		conductor.setApellidos("JK");
		try {
			tmioConductoresDAO.update(entityManager, conductor);
		} catch (Exception e) {
			// TODO: handle exception
			tmioConductoresDAO.rollback(entityManager);
		}
	

		tmioConductoresDAO.cerrarT(entityManager);
	}

	 @Test
	 public void cTest() {
	
	 assertNotNull(tmioConductoresDAO);
	 tmioConductoresDAO.iniciarT(entityManager);
	 Tmio1Conductore Tmio1Conductore =
	 tmioConductoresDAO.findByCedula(entityManager, "12326");
	 assertNotNull("Code not found", Tmio1Conductore);
	 try {
	 tmioConductoresDAO.delete(entityManager, Tmio1Conductore);
	 } catch (Exception e) {
	 // TODO: handle exception
	 tmioConductoresDAO.rollback(entityManager);
	 }

	
	 tmioConductoresDAO.cerrarT(entityManager);
	
	
	 }
}
