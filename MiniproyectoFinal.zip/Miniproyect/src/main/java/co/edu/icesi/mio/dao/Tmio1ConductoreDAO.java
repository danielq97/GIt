package co.edu.icesi.mio.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;


import co.edu.icesi.mio.model.Tmio1Conductore;


public class Tmio1ConductoreDAO implements ITMio1ConductoreDAO {

	@Override
	public void save(EntityManager entityManager, Tmio1Conductore entity) {
		// TODO Auto-generated method stub
		entityManager.persist(entity);
	}

	@Override
	public void update(EntityManager entityManager, Tmio1Conductore entity) {
		// TODO Auto-generated method stub
		entityManager.merge(entity);
	}

	@Override
	public void delete(EntityManager entityManager, Tmio1Conductore entity) {
		// TODO Auto-generated method stub
		entityManager.remove(entity);
	}

	@Override
	public Tmio1Conductore findByNombre(EntityManager entityManager, String nombre) {
		// TODO Auto-generated method stub
		return entityManager.find(Tmio1Conductore.class, nombre);
	}

	@Override
	public Tmio1Conductore findByCedula(EntityManager entityManager, String cedula) {
		// TODO Auto-generated method stub
		return entityManager.find(Tmio1Conductore.class, cedula);
	}

	@Override
	public Tmio1Conductore findByApellidos(EntityManager entityManager, String apellidos) {
		// TODO Auto-generated method stub
		return entityManager.find(Tmio1Conductore.class, apellidos);
	}

	@Override
	public List<Tmio1Conductore> findAll(EntityManager entityManager) {
		// TODO Auto-generated method stub
		String jpql = "Select a from Tmio1Conductore a";
		return entityManager.createQuery(jpql).getResultList();
	}

	@Override
	public void iniciarT(EntityManager entityManager) {
		// TODO Auto-generated method stub
		EntityTransaction trans = entityManager.getTransaction();
		trans.begin();
	}

	@Override
	public void cerrarT(EntityManager entityManager) {
		// TODO Auto-generated method stub
		EntityTransaction trans = entityManager.getTransaction();
		trans.commit();
	}

	@Override
	public void rollback(EntityManager entityManager) {
		// TODO Auto-generated method stub
		EntityTransaction trans = entityManager.getTransaction();
		trans.rollback();
	}
	
	public void otra(EntityManager entityManager) {
		Query query =    entityManager
				.createQuery("SELECT t FROM Tmio1Conductore t ORDER BY TO_DATE(t.fechaNacimiento, \"DD/MM/YY\") DESC");
		List<String> list = query.getResultList();

	
	}

}
