package co.edu.icesi.mio.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import co.edu.icesi.mio.model.Tmio1Servicio;

public class Tmio1ServicioDAO implements ITmio1ServicioDAO{

	@Override
	public void save(EntityManager entityManager, Tmio1Servicio entity) {
		// TODO Auto-generated method stub
		entityManager.persist(entity);
	}

	@Override
	public void update(EntityManager entityManager, Tmio1Servicio entity) {
		// TODO Auto-generated method stub
		entityManager.merge(entity);
	}

	@Override
	public void delete(EntityManager entityManager, Tmio1Servicio entity) {
		// TODO Auto-generated method stub
		entityManager.remove(entity);
	}

	@Override
	public List<Tmio1Servicio> findAll(EntityManager entityManager) {
		// TODO Auto-generated method stub
		String jpql = "Select a from Tmio1Servicio a";
		return entityManager.createQuery(jpql).getResultList();
	}

	@Override
	public void iniciarT(EntityManager entityManager) {
		// TODO Auto-generated method stub
		EntityTransaction trans = entityManager.getTransaction();
		trans.begin();
		
	}

	@Override
	public void cerrarT(EntityManager entityManager) {
		// TODO Auto-generated method stub
		EntityTransaction trans = entityManager.getTransaction();
		trans.commit();
	}

	@Override
	public void rollback(EntityManager entityManager) {
		// TODO Auto-generated method stub
		EntityTransaction trans = entityManager.getTransaction();
		trans.rollback();
	}

}
