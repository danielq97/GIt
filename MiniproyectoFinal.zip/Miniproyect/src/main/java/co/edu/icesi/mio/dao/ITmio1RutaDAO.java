package co.edu.icesi.mio.dao;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.EntityManager;

import co.edu.icesi.mio.model.Tmio1Ruta;

public interface ITmio1RutaDAO {
	

	public void save(EntityManager entityManager,Tmio1Ruta entity);
	public void update(EntityManager entityManager,Tmio1Ruta entity);
	public void delete(EntityManager entityManager,Tmio1Ruta entity);
	public List <Tmio1Ruta> findByRangoDias(EntityManager entityManager,BigDecimal diaInicio,BigDecimal diaFin);
	public Tmio1Ruta findById(EntityManager entityManager,int id);
	public List<Tmio1Ruta> findAll(EntityManager entityManager);
	public void iniciarT(EntityManager entityManager);
	public void cerrarT(EntityManager entityManager);
	public void rollback(EntityManager entityManager);
   
}
