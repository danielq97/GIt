package co.edu.icesi.mio.dao;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import co.edu.icesi.mio.model.Tmio1Bus;
import co.edu.icesi.mio.model.Tmio1Ruta;

public class Tmio1RutaDAO implements ITmio1RutaDAO{

	@Override
	public void save(EntityManager entityManager, Tmio1Ruta entity) {
		// TODO Auto-generated method stub
		entityManager.persist(entity);
	}

	@Override
	public void update(EntityManager entityManager, Tmio1Ruta entity) {
		// TODO Auto-generated method stub
		entityManager.merge(entity);
	}

	@Override
	public void delete(EntityManager entityManager, Tmio1Ruta entity) {
		// TODO Auto-generated method stub
		entityManager.remove(entity);
	}

	@Override
	public List <Tmio1Ruta> findByRangoDias(EntityManager entityManager, BigDecimal diaInicio, BigDecimal diaFin) {
		// TODO Auto-generated method stub
		String jpql = "Select a from Tmio1Ruta a where a.diaInicio <=" + diaInicio + " ' and a.diaFin >= '" + diaFin + "'";
		return entityManager.createQuery(jpql).getResultList();
	}

	@Override
	public List<Tmio1Ruta> findAll(EntityManager entityManager) {
		// TODO Auto-generated method stub
		String jpql = "Select a from Tmio1Ruta a";
		return entityManager.createQuery(jpql).getResultList();
	}

	@Override
	public void iniciarT(EntityManager entityManager) {
		// TODO Auto-generated method stub
		EntityTransaction trans = entityManager.getTransaction();
		trans.begin();
	}

	@Override
	public void cerrarT(EntityManager entityManager) {
		// TODO Auto-generated method stub
		EntityTransaction trans = entityManager.getTransaction();
		trans.commit();
	}

	@Override
	public void rollback(EntityManager entityManager) {
		// TODO Auto-generated method stub
		EntityTransaction trans = entityManager.getTransaction();
		trans.rollback();
	}

	@Override
	public Tmio1Ruta findById(EntityManager entityManager, int id) {
		// TODO Auto-generated method stub
		return entityManager.find(Tmio1Ruta.class, id);
	}

}
