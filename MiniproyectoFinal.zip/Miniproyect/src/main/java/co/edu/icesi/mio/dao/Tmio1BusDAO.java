package co.edu.icesi.mio.dao;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import co.edu.icesi.mio.model.Tmio1Bus;
import co.edu.icesi.mio.model.Tmio1Conductore;

public class Tmio1BusDAO implements ITmio1BusDAO{

	@Override
	public void save(EntityManager entityManager, Tmio1Bus entity) {
		// TODO Auto-generated method stub
		entityManager.persist(entity);
	}

	@Override
	public void update(EntityManager entityManager, Tmio1Bus entity) {
		// TODO Auto-generated method stub
		entityManager.merge(entity);
	}

	@Override
	public void delete(EntityManager entityManager, Tmio1Bus entity) {
		// TODO Auto-generated method stub
		entityManager.remove(entity);
	}

	@Override
	public Tmio1Bus findByModelo(EntityManager entityManager, BigDecimal modelo) {
		// TODO Auto-generated method stub
		return entityManager.find(Tmio1Bus.class, modelo);
	}

	@Override
	public Tmio1Bus findByCapacidad(EntityManager entityManager, BigDecimal capacidad) {
		// TODO Auto-generated method stub
		return entityManager.find(Tmio1Bus.class, capacidad);
	}

	@Override
	public Tmio1Bus findByTipo(EntityManager entityManager, String tipo) {
		// TODO Auto-generated method stub
		return entityManager.find(Tmio1Bus.class, tipo);
	}

	@Override
	public List<Tmio1Bus> findAll(EntityManager entityManager) {
		// TODO Auto-generated method stub
		String jpql = "Select a from Tmio1Bus a";
		return entityManager.createQuery(jpql).getResultList();
	}

	@Override
	public void iniciarT(EntityManager entityManager) {
		// TODO Auto-generated method stub
		EntityTransaction trans = entityManager.getTransaction();
		trans.begin();
	}

	@Override
	public void cerrarT(EntityManager entityManager) {
		// TODO Auto-generated method stub
		EntityTransaction trans = entityManager.getTransaction();
		trans.commit();
	}

	@Override
	public void rollback(EntityManager entityManager) {
		// TODO Auto-generated method stub
		EntityTransaction trans = entityManager.getTransaction();
		trans.rollback();
	}

}
