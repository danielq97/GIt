package co.edu.icesi.mio.dao;

import java.util.List;

import javax.persistence.EntityManager;

import co.edu.icesi.mio.model.Tmio1Conductore;

public interface ITMio1ConductoreDAO {

	public void save(EntityManager entityManager,Tmio1Conductore entity);
	public void update(EntityManager entityManager,Tmio1Conductore entity);
	public void delete(EntityManager entityManager,Tmio1Conductore entity);
	public Tmio1Conductore findByNombre(EntityManager entityManager,String nombre);
	public Tmio1Conductore findByCedula(EntityManager entityManager,String cedula);
	public Tmio1Conductore findByApellidos(EntityManager entityManager,String apellidos);
	public List<Tmio1Conductore> findAll(EntityManager entityManager);
	public void iniciarT(EntityManager entityManager);
	public void cerrarT(EntityManager entityManager);
	public void rollback(EntityManager entityManager);
	
	
	
}
